import { Contract } from './contract';

describe('Contract', () => {
  it('should create an instance', () => {
    expect(new Contract()).toBeTruthy();
  });
});
