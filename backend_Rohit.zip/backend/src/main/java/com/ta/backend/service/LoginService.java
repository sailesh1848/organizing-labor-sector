package com.ta.backend.service;

import org.springframework.stereotype.Service;

import com.ta.backend.entity.Login;

@Service
public interface LoginService {
	
	public Login getById(String id);
	
	public Login addCred(Login log); 
		

}
