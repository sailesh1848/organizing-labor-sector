package com.example.demo.exception;

public class GovtUserDataInvalidException extends RuntimeException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GovtUserDataInvalidException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GovtUserDataInvalidException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public GovtUserDataInvalidException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public GovtUserDataInvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GovtUserDataInvalidException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
