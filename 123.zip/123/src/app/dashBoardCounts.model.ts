export class DashBoardCounts {
  employersCount: number;
  pendingEmployers: number;
  approvedEmployers: number;
  labourersCount: number;
  activeLabourers: number;
  inActiveLabourers: number;
  govtUserCount: number;
  activeGovtUsers: number;
  inActiveGovtUsers: number;
  contractCount: number;
}
